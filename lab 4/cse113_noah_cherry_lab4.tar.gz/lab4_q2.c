#include <stdio.h> 

enum color
{
    RED = 18, ORANGE , YELLOW = 5, GREEN , BLUE , INDIGO = 14, VIOLET
};

int main()
{

    printf("RED is %d, ORANGE is %d, YELLOW is %d, GREEN is %d BLUE is %d, INDIGO is %d, VIOLET is %d\n", RED, ORANGE, YELLOW, GREEN, BLUE, INDIGO, VIOLET);

    return 0;
}
