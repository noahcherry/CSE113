#include<stdio.h>

int main(void)
{
	/*Write code for your main() for your Array Problems here*/
}
