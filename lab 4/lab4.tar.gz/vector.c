#include<stdio.h>

/* Place all of your functions here for your Array Problems */
