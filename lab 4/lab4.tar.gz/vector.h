#ifndef VECTOR_H_
#define VECTOR_H_

/* Place all of your function prototypes here for your Array Problems, #1-8 */

#endif
