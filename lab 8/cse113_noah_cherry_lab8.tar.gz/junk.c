#include <stdio.h>

int main()
{
    int y;
    int *x;

    x = &y;
    *x = y;

    return 0;


}
