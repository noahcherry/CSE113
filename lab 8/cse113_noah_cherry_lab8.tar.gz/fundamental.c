#include "stdio.h"



int main(void)
{
        double p = 3.14159;
        double *x = &p;
        printf("%p : %f\n", &p, p);
        *x = 2.71828;
        printf("%p : %f\n", &p, p);

        return 0;
}