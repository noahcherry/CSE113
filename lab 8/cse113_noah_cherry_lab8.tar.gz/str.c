#include "str.h"
#include <stdio.h>

int str_len(char *s)
{
        int count = 0;
        char *tmp = s;
        while(*tmp != '\0') {
                tmp++;
                count++;
        }
	return count;
}

void reverse(char s[])
{
	int c, i, j;

	for(i = 0, j = str_len(s) - 1; i < j; i++, j-- ) {
		/* change this so it calls cswap */
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	}
	
}

/* copy n chars of src into dest */
void pstr_ncpy(char *dest, char *src, int n)
{
        int count = 0;
        /*plus one to get the NULL terminator in there*/
        while(count < n+1) {
                *dest = *src;
                dest++;
                src++;
                count++;
        }
}

/* concantenate t to the end of s; s must be big enough! */
void pstr_cat(char *s, char *t)
{
	int j;
        char *tmp = s;

        j = 0;
	while(*tmp != '\0') 	/* find end of s */
		tmp++;
	while(*t != '\0') { /* copy t */
		*tmp = *t;
                tmp++;
                t++;
        }
}

int pstr_ncmp(char *s, char *t, int n)
{
        int count = 0;
        while(count < n && *s == *t) {
                s++;
                t++;
        }
        if(count == n)
                return 0;                      
        else if(*s < *t) 
                return 1;
        else
                return -1;
}

char *pindex(char *s, int c)
{
        char *tmp = s;
        while(*tmp != c && *tmp != '\0')
                tmp++;
        if(*tmp == c)
                return tmp;
        else
                return NULL;
}

void psqueeze(char *s, int c)
{
        char *tmp = s;
        while(*s != '\0') {
                if(*s != c) {
                        *tmp = *s;
                        tmp++;
                }
                s++;
        }
        *tmp = '\0';
}

void cswap(char *c, char *d)
{
	int tmp = *c;
	*c = *d;
	*d = tmp;
}

void preverse(char *s)
{
        int i = 0, count = 0;
	char *tmp = s;
        while(*tmp != '\0') {
                tmp++;
                count++;
        }
        tmp--;

	while(i < count) {
		/* change this so it calls cswap */
		cswap(s, tmp);
                s++;
                tmp--;
                i++;
                count--;
	}
}